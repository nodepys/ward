let autosecureMap = new Map();

module.exports = { autosecureMap };
